# Ford go Bike Data Exploration 
## by Clifford Effum


## Dataset

The data is made up of informaiton about individual rides made in a bike sharing system covering the greater San Francisco Bay area in Carliforni for February, 2019. The data set is available at [here](https://video.udacity-data.com/topher/2020/October/5f91cf38_201902-fordgobike-tripdata/201902-fordgobike-tripdata.csv).

### Features:

The Features in the dataset include:
- duration_sec
- start_time 
- end_time 
- start_station_id 
- start_station_name
- start_station_latitude
- start_station_longitude
- end_station_id
- end_station_name
- end_station_latitude
- end_station_longitude
- bike_id
- user_type
- member_birth_year
- member_gender
- bike_share_for_all_trip


## Summary of Findings

From the univariate data exploration I found the following:
- Most users of the bike sharing service are males
- The most frequent starting point is Market St at 10th St
- Most riders end up returning bikes to the San Francisco Caltrain Station 2. 
- he most start - end station combination is Berry St at 4th St - San Francisco Ferry Building (Harry Bridges Plaza)
- Most bikes are rented for 5 - 10 minutes
- Most users of the service are subscribers
- Most people do not use bikes for their whole trips
- The top 10 ridersare between 24 and 33 years with those who are 31 years of age dorminating.
- The day with the highest number of rental was Thursday while Saturday and Sunday recorded the least
- Most people use bicycles within 1-2 km radius while only a few end their rides 5km away from their starting points.

Findings from Bivariate exploration:
- Both random cutomers and subscribers used the bike sharing system mostly on Thursday. 
- The relative percentage of random customer who used the bike sharing sytem was higher than subribers only on Saturday and Sunday. 
- No customer used the bike sharing system for their entire trip.
- There is no correlation between the age of a user, distance travelled and the time spent during the rental.

Findings from Multivariate exploaration:
- Customers spend more time during their rental than subscribers.
- Customers mostly rent bikes during weekends whiles subscribers use bikes during rush hours on weekdays.
- On Saturdays, Montgomery and Powell St Bart Stations recorded the highest number of rental starting points.
- On weekends, the San Francisco Ferry Building (Harry Bridges Plaza) and the Montgomery St Bart Stations seem to be the destination of most riders.


## Key Insights for Presentation

- Subscribers and customers have different motives for renting bikes. Subscribers mostly use bikes for commuting whiles customers use it for pleasure. It also appears that customers use bikes for longer hours than subscribers. The profit motive of bike rental companies should drive them into getting more customers and subsequetly converting them into becoming subscribers.
- The distribution of bikes at various stations should be varied considering the lifestyle of users.